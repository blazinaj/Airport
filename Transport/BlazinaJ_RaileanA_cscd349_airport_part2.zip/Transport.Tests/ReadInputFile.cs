using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Transport.Tests
{
    [TestClass]
    public class ReadInputFile
    {
        [TestMethod]
        public void ReadFromArgs_Success()
        {
            
        }
    }
}
