﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Transport.UserMenu
{
    abstract class UserMenu
    {
        public abstract string DisplayMenu();

        public abstract void DisplaySystemDetails();
    }
}
