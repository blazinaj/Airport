﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Transport.Menu
{
    abstract class SystemMenu
    {
        public abstract string DisplayMenu();
    }
}
