﻿namespace Transport
{
    public enum SeatClass
    {
        E, F, B
    }
}