CSCD 349 Airport Part 1

Contributors: 
Anatoli Railean
Jacob Blazina

Project Management Board :
https://trello.com/b/knbl4jZD/cscd349-airport

Github Repository :
https://github.com/blazinaj/Airport/tree/part1

Tidbits:

1. Used Test Driven Development with Unit Tests for every class.
2. Methods return a string as well as print to the console to enable unit testing.
3. Created Custom Exception Classes, with Try/Catch blocks.
4. CreateFlight must be a current or future date.
5. Used Project Management tool Trello.
6. Used Software Development framework Scrum.
7. Used Pull Requests for code reviewing with Github.
8. Used Factories to abstract creation logic.
9. Used Interfaces to abstract display logic.