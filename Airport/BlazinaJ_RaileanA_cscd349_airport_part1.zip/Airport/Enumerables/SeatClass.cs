﻿namespace Airport
{
    public enum SeatClass
    {
        economy, first, business
    }
}