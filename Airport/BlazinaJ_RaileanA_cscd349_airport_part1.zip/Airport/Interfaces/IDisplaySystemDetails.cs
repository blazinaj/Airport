﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Airport
{
    interface IDisplaySystemDetails
    {
        string DisplaySystemDetails();
    }
}
